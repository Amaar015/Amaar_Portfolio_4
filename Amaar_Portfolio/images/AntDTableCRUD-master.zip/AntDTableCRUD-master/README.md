# AntDTableCRUD
This repo contains code base regarding youtube tutorial (https://youtu.be/y4_nSE-aZhc) on how to implement Table CRUD like how to populate rows, add new rows, delete rows, edit rows in antd table.

Notes: If somehow due to difference in react versions or so, it is not compiled correctly then you can use the code from App.js file into your project directly.
